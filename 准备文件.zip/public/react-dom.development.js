/**
 * @license React
 * react-dom.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

"use strict";
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart ===
    "function"
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
}
(function (global, factory) {
  typeof exports === "object" && typeof module !== "undefined"
    ? factory(exports, require("react"))
    : typeof define === "function" && define.amd
      ? define(["exports", "react"], factory)
      : ((global =
          typeof globalThis !== "undefined" ? globalThis : global || self),
        factory((global.ReactDOM = {}), global.React));
})(this, function (exports, React) {
  function noop() {}

  // This should line up with NoEventPriority from react-reconciler/src/ReactEventPriorities
  // but we can't depend on the react-reconciler from this isomorphic code.
  const NoEventPriority = 0;
  function requestFormReset$1(element) {
    throw new Error(
      "Invalid form element. requestFormReset must be passed a form that was " +
        "rendered by React."
    );
  }
  const DefaultDispatcher = {
    f /* flushSyncWork */: noop,
    r /* requestFormReset */: requestFormReset$1,
    D /* prefetchDNS */: noop,
    C /* preconnect */: noop,
    L /* preload */: noop,
    m /* preloadModule */: noop,
    X /* preinitScript */: noop,
    S /* preinitStyle */: noop,
    M /* preinitModuleScript */: noop
  };
  const Internals = {
    d /* ReactDOMCurrentDispatcher */: DefaultDispatcher,
    p /* currentUpdatePriority */: NoEventPriority,
    findDOMNode: null
  };

  var ReactVersion = "19.2.0-canary-8ce15b0f-20250522";

  // -----------------------------------------------------------------------------
  // Land or remove (zero effort)
  //
  // Flags that can likely be deleted or landed without consequences
  // -----------------------------------------------------------------------------

  // -----------------------------------------------------------------------------
  // Chopping Block
  //
  // Planned feature deprecations and breaking changes. Sorted roughly in order of
  // when we plan to enable them.
  // -----------------------------------------------------------------------------

  // -----------------------------------------------------------------------------
  // React DOM Chopping Block
  //
  // Similar to main Chopping Block but only flags related to React DOM. These are
  // grouped because we will likely batch all of them into a single major release.
  // -----------------------------------------------------------------------------

  // Disable support for comment nodes as React DOM containers. Already disabled
  // in open source, but www codebase still relies on it. Need to remove.
  const disableCommentsAsDOMContainers = true;

  /**
   * HTML nodeType values that represent the type of the node
   */

  const ELEMENT_NODE = 1;
  const DOCUMENT_NODE = 9;
  const DOCUMENT_FRAGMENT_NODE = 11;

  function isValidContainer(node) {
    return !!(
      node &&
      (node.nodeType === ELEMENT_NODE ||
        node.nodeType === DOCUMENT_NODE ||
        node.nodeType === DOCUMENT_FRAGMENT_NODE ||
        !disableCommentsAsDOMContainers)
    );
  }

  const REACT_PORTAL_TYPE = Symbol.for("react.portal");

  function createPortal$1(
    children,
    containerInfo,
    // TODO: figure out the API for cross-renderer implementation.
    implementation,
    key = null
  ) {
    return {
      // This tag allow us to uniquely identify this as a React Portal
      $$typeof: REACT_PORTAL_TYPE,
      key: key == null ? null : "" + key,
      children,
      containerInfo,
      implementation
    };
  }

  // TODO: Ideally these types would be opaque but that doesn't work well with
  // our reconciler fork infra, since these leak into non-reconciler packages.

  const SyncLane = /*                        */ 0b0000000000000000000000000000010;

  const DiscreteEventPriority = SyncLane;

  const ReactSharedInternals =
    React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

  function flushSyncImpl(fn) {
    const previousTransition = ReactSharedInternals.T;
    const previousUpdatePriority =
      Internals.p; /* ReactDOMCurrentUpdatePriority */

    try {
      ReactSharedInternals.T = null;
      Internals.p /* ReactDOMCurrentUpdatePriority */ = DiscreteEventPriority;
      if (fn) {
        return fn();
      } else {
        return undefined;
      }
    } finally {
      ReactSharedInternals.T = previousTransition;
      Internals.p /* ReactDOMCurrentUpdatePriority */ = previousUpdatePriority;
      Internals.d /* ReactDOMCurrentDispatcher */
        .f(); /* flushSyncWork */
    }
  }
  const flushSync = flushSyncImpl;

  function getCrossOriginString(input) {
    if (typeof input === "string") {
      return input === "use-credentials" ? input : "";
    }
    return undefined;
  }
  function getCrossOriginStringAs(as, input) {
    if (as === "font") {
      return "";
    }
    if (typeof input === "string") {
      return input === "use-credentials" ? input : "";
    }
    return undefined;
  }

  function prefetchDNS(href) {
    if (typeof href === "string") {
      Internals.d /* ReactDOMCurrentDispatcher */
        .D(/* prefetchDNS */ href);
    }
    // We don't error because preconnect needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }
  function preconnect(href, options) {
    if (typeof href === "string") {
      const crossOrigin = options
        ? getCrossOriginString(options.crossOrigin)
        : null;
      Internals.d /* ReactDOMCurrentDispatcher */
        .C(/* preconnect */ href, crossOrigin);
    }
    // We don't error because preconnect needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }
  function preload(href, options) {
    if (
      typeof href === "string" &&
      // We check existence because we cannot enforce this function is actually called with the stated type
      typeof options === "object" &&
      options !== null &&
      typeof options.as === "string"
    ) {
      const as = options.as;
      const crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
      Internals.d /* ReactDOMCurrentDispatcher */
        .L(/* preload */ href, as, {
          crossOrigin,
          integrity:
            typeof options.integrity === "string"
              ? options.integrity
              : undefined,
          nonce: typeof options.nonce === "string" ? options.nonce : undefined,
          type: typeof options.type === "string" ? options.type : undefined,
          fetchPriority:
            typeof options.fetchPriority === "string"
              ? options.fetchPriority
              : undefined,
          referrerPolicy:
            typeof options.referrerPolicy === "string"
              ? options.referrerPolicy
              : undefined,
          imageSrcSet:
            typeof options.imageSrcSet === "string"
              ? options.imageSrcSet
              : undefined,
          imageSizes:
            typeof options.imageSizes === "string"
              ? options.imageSizes
              : undefined,
          media: typeof options.media === "string" ? options.media : undefined
        });
    }
    // We don't error because preload needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }
  function preloadModule(href, options) {
    if (typeof href === "string") {
      if (options) {
        const crossOrigin = getCrossOriginStringAs(
          options.as,
          options.crossOrigin
        );
        Internals.d /* ReactDOMCurrentDispatcher */
          .m(/* preloadModule */ href, {
            as:
              typeof options.as === "string" && options.as !== "script"
                ? options.as
                : undefined,
            crossOrigin,
            integrity:
              typeof options.integrity === "string"
                ? options.integrity
                : undefined
          });
      } else {
        Internals.d /* ReactDOMCurrentDispatcher */
          .m(/* preloadModule */ href);
      }
    }
    // We don't error because preload needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }
  function preinit(href, options) {
    if (typeof href === "string" && options && typeof options.as === "string") {
      const as = options.as;
      const crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
      const integrity =
        typeof options.integrity === "string" ? options.integrity : undefined;
      const fetchPriority =
        typeof options.fetchPriority === "string"
          ? options.fetchPriority
          : undefined;
      if (as === "style") {
        Internals.d /* ReactDOMCurrentDispatcher */
          .S(
            /* preinitStyle */
            href,
            typeof options.precedence === "string"
              ? options.precedence
              : undefined,
            {
              crossOrigin,
              integrity,
              fetchPriority
            }
          );
      } else if (as === "script") {
        Internals.d /* ReactDOMCurrentDispatcher */
          .X(/* preinitScript */ href, {
            crossOrigin,
            integrity,
            fetchPriority,
            nonce: typeof options.nonce === "string" ? options.nonce : undefined
          });
      }
    }
    // We don't error because preinit needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }
  function preinitModule(href, options) {
    if (typeof href === "string") {
      if (typeof options === "object" && options !== null) {
        if (options.as == null || options.as === "script") {
          const crossOrigin = getCrossOriginStringAs(
            options.as,
            options.crossOrigin
          );
          Internals.d /* ReactDOMCurrentDispatcher */
            .M(/* preinitModuleScript */ href, {
              crossOrigin,
              integrity:
                typeof options.integrity === "string"
                  ? options.integrity
                  : undefined,
              nonce:
                typeof options.nonce === "string" ? options.nonce : undefined
            });
        }
      } else if (options == null) {
        Internals.d /* ReactDOMCurrentDispatcher */
          .M(/* preinitModuleScript */ href);
      }
    }
    // We don't error because preinit needs to be resilient to being called in a variety of scopes
    // and the runtime may not be capable of responding. The function is optimistic and not critical
    // so we favor silent bailout over warning or erroring.
  }

  function resolveDispatcher() {
    // Copied from react/src/ReactHooks.js. It's the same thing but in a
    // different package.
    const dispatcher = ReactSharedInternals.H;
    // Will result in a null access error if accessed outside render phase. We
    // intentionally don't throw our own error because this is in a hot path.
    // Also helps ensure this is inlined.
    return dispatcher;
  }
  function useFormStatus() {
    const dispatcher = resolveDispatcher();
    return dispatcher.useHostTransitionStatus();
  }
  function useFormState(action, initialState, permalink) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useFormState(action, initialState, permalink);
  }
  function requestFormReset(form) {
    Internals.d /* ReactDOMCurrentDispatcher */
      .r(/* requestFormReset */ form);
  }

  function batchedUpdates(fn, a) {
    // batchedUpdates is now just a passthrough noop
    return fn(a);
  }
  function createPortal(children, container, key = null) {
    if (!isValidContainer(container)) {
      throw new Error("Target container is not a DOM element.");
    }

    // TODO: pass ReactDOM portal implementation as third argument
    // $FlowFixMe[incompatible-return] The Flow type is opaque but there's no way to actually create it.
    return createPortal$1(children, container, null, key);
  }

  exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE =
    Internals;
  exports.createPortal = createPortal;
  exports.flushSync = flushSync;
  exports.preconnect = preconnect;
  exports.prefetchDNS = prefetchDNS;
  exports.preinit = preinit;
  exports.preinitModule = preinitModule;
  exports.preload = preload;
  exports.preloadModule = preloadModule;
  exports.requestFormReset = requestFormReset;
  exports.unstable_batchedUpdates = batchedUpdates;
  exports.useFormState = useFormState;
  exports.useFormStatus = useFormStatus;
  exports.version = ReactVersion;
});
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop ===
    "function"
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
}
