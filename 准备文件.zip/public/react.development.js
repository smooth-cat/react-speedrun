/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

"use strict";
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart ===
    "function"
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
}
(function (global, factory) {
  typeof exports === "object" && typeof module !== "undefined"
    ? factory(exports)
    : typeof define === "function" && define.amd
      ? define(["exports"], factory)
      : ((global =
          typeof globalThis !== "undefined" ? globalThis : global || self),
        factory((global.React = {})));
})(this, function (exports) {
  var ReactVersion = "19.2.0-canary-8ce15b0f-20250522";

  const REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
  const REACT_PORTAL_TYPE = Symbol.for("react.portal");
  const REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
  const REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
  const REACT_PROFILER_TYPE = Symbol.for("react.profiler");
  const REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
  const REACT_CONTEXT_TYPE = Symbol.for("react.context");
  const REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
  const REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
  const REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
  const REACT_MEMO_TYPE = Symbol.for("react.memo");
  const REACT_LAZY_TYPE = Symbol.for("react.lazy");
  const REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
  const REACT_POSTPONE_TYPE = Symbol.for("react.postpone");
  const REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition");
  const MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
  const FAUX_ITERATOR_SYMBOL = "@@iterator";
  function getIteratorFn(maybeIterable) {
    if (maybeIterable === null || typeof maybeIterable !== "object") {
      return null;
    }
    const maybeIterator =
      (MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL]) ||
      maybeIterable[FAUX_ITERATOR_SYMBOL];
    if (typeof maybeIterator === "function") {
      return maybeIterator;
    }
    return null;
  }

  /**
   * This is the abstract API for an update queue.
   */
  const ReactNoopUpdateQueue = {
    /**
     * Checks whether or not this composite component is mounted.
     * @param {ReactClass} publicInstance The instance we want to test.
     * @return {boolean} True if mounted, false otherwise.
     * @protected
     * @final
     */
    isMounted: function (publicInstance) {
      return false;
    },
    /**
     * Forces an update. This should only be invoked when it is known with
     * certainty that we are **not** in a DOM transaction.
     *
     * You may want to call this when you know that some deeper aspect of the
     * component's state has changed but `setState` was not called.
     *
     * This will not invoke `shouldComponentUpdate`, but it will invoke
     * `componentWillUpdate` and `componentDidUpdate`.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @param {?function} callback Called after component is updated.
     * @param {?string} callerName name of the calling function in the public API.
     * @internal
     */
    enqueueForceUpdate: function (publicInstance, callback, callerName) {},
    /**
     * Replaces all of the state. Always use this or `setState` to mutate state.
     * You should treat `this.state` as immutable.
     *
     * There is no guarantee that `this.state` will be immediately updated, so
     * accessing `this.state` after calling this method may return the old value.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @param {object} completeState Next state.
     * @param {?function} callback Called after component is updated.
     * @param {?string} callerName name of the calling function in the public API.
     * @internal
     */
    enqueueReplaceState: function (
      publicInstance,
      completeState,
      callback,
      callerName
    ) {},
    /**
     * Sets a subset of the state. This only exists because _pendingState is
     * internal. This provides a merging strategy that is not available to deep
     * properties which is confusing. TODO: Expose pendingState or don't use it
     * during the merge.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @param {object} partialState Next partial state to be merged with state.
     * @param {?function} callback Called after component is updated.
     * @param {?string} Name of the calling function in the public API.
     * @internal
     */
    enqueueSetState: function (
      publicInstance,
      partialState,
      callback,
      callerName
    ) {}
  };

  const assign = Object.assign;

  const emptyObject = {};

  /**
   * Base class helpers for the updating state of a component.
   */
  function Component(props, context, updater) {
    this.props = props;
    this.context = context;
    // If a component has string refs, we will assign a different object later.
    this.refs = emptyObject;
    // We initialize the default updater but the real one gets injected by the
    // renderer.
    this.updater = updater || ReactNoopUpdateQueue;
  }
  Component.prototype.isReactComponent = {};

  /**
   * Sets a subset of the state. Always use this to mutate
   * state. You should treat `this.state` as immutable.
   *
   * There is no guarantee that `this.state` will be immediately updated, so
   * accessing `this.state` after calling this method may return the old value.
   *
   * There is no guarantee that calls to `setState` will run synchronously,
   * as they may eventually be batched together.  You can provide an optional
   * callback that will be executed when the call to setState is actually
   * completed.
   *
   * When a function is provided to setState, it will be called at some point in
   * the future (not synchronously). It will be called with the up to date
   * component arguments (state, props, context). These values can be different
   * from this.* because your function may be called after receiveProps but before
   * shouldComponentUpdate, and this new state, props, and context will not yet be
   * assigned to this.
   *
   * @param {object|function} partialState Next partial state or function to
   *        produce next partial state to be merged with current state.
   * @param {?function} callback Called after state is updated.
   * @final
   * @protected
   */
  Component.prototype.setState = function (partialState, callback) {
    if (
      typeof partialState !== "object" &&
      typeof partialState !== "function" &&
      partialState != null
    ) {
      throw new Error(
        "takes an object of state variables to update or a " +
          "function which returns an object of state variables."
      );
    }
    this.updater.enqueueSetState(this, partialState, callback, "setState");
  };

  /**
   * Forces an update. This should only be invoked when it is known with
   * certainty that we are **not** in a DOM transaction.
   *
   * You may want to call this when you know that some deeper aspect of the
   * component's state has changed but `setState` was not called.
   *
   * This will not invoke `shouldComponentUpdate`, but it will invoke
   * `componentWillUpdate` and `componentDidUpdate`.
   *
   * @param {?function} callback Called after update is complete.
   * @final
   * @protected
   */
  Component.prototype.forceUpdate = function (callback) {
    this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
  };
  function ComponentDummy() {}
  ComponentDummy.prototype = Component.prototype;

  /**
   * Convenience component with default shallow equality check for sCU.
   */
  function PureComponent(props, context, updater) {
    this.props = props;
    this.context = context;
    // If a component has string refs, we will assign a different object later.
    this.refs = emptyObject;
    this.updater = updater || ReactNoopUpdateQueue;
  }
  const pureComponentPrototype = (PureComponent.prototype =
    new ComponentDummy());
  pureComponentPrototype.constructor = PureComponent;
  // Avoid an extra prototype jump for these methods.
  assign(pureComponentPrototype, Component.prototype);
  pureComponentPrototype.isPureReactComponent = true;

  // an immutable object with a single mutable value
  function createRef() {
    const refObject = {
      current: null
    };
    return refObject;
  }

  const isArrayImpl = Array.isArray;
  function isArray(a) {
    return isArrayImpl(a);
  }

  function noop() {}

  const ReactSharedInternals = {
    H: null,
    A: null,
    T: null,
    S: null
  };
  {
    ReactSharedInternals.G = null;
  }

  // $FlowFixMe[method-unbinding]
  const hasOwnProperty = Object.prototype.hasOwnProperty;

  function getOwner() {
    return null;
  }
  function hasValidRef(config) {
    return config.ref !== undefined;
  }
  function hasValidKey(config) {
    return config.key !== undefined;
  }

  /**
   * Factory method to create a new React element. This no longer adheres to
   * the class pattern, so do not use new to call it. Also, instanceof check
   * will not work. Instead test $$typeof field against Symbol.for('react.transitional.element') to check
   * if something is a React Element.
   *
   * @param {*} type
   * @param {*} props
   * @param {*} key
   * @param {string|object} ref
   * @param {*} owner
   * @param {*} self A *temporary* helper to detect places where `this` is
   * different from the `owner` when React.createElement is called, so that we
   * can warn. We want to get rid of owner and replace string `ref`s with arrow
   * functions, and as long as `this` and owner are the same, there will be no
   * change in behavior.
   * @param {*} source An annotation object (added by a transpiler or otherwise)
   * indicating filename, line number, and/or other information.
   * @internal
   */
  function ReactElement(
    type,
    key,
    self,
    source,
    owner,
    props,
    debugStack,
    debugTask
  ) {
    // Ignore whatever was passed as the ref argument and treat `props.ref` as
    // the source of truth. The only thing we use this for is `element.ref`,
    // which will log a deprecation warning on access. In the next release, we
    // can remove `element.ref` as well as the `ref` argument.
    const refProp = props.ref;

    // An undefined `element.ref` is coerced to `null` for
    // backwards compatibility.
    const ref = refProp !== undefined ? refProp : null;
    let element;
    {
      // In prod, `ref` is a regular property and _owner doesn't exist.
      element = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: REACT_ELEMENT_TYPE,
        // Built-in properties that belong on the element
        type,
        key,
        ref,
        props
      };
    }
    return element;
  }

  /**
   * Create and return a new ReactElement of the given type.
   * See https://reactjs.org/docs/react-api.html#createelement
   */
  function createElement(type, config, children) {
    let propName;

    // Reserved names are extracted
    const props = {};
    let key = null;
    if (config != null) {
      if (hasValidKey(config)) {
        key = "" + config.key;
      }

      // Remaining properties are added to a new props object
      for (propName in config) {
        if (
          hasOwnProperty.call(config, propName) &&
          // Skip over reserved prop names
          propName !== "key" &&
          // Even though we don't use these anymore in the runtime, we don't want
          // them to appear as props, so in createElement we filter them out.
          // We don't have to do this in the jsx() runtime because the jsx()
          // transform never passed these as props; it used separate arguments.
          propName !== "__self" &&
          propName !== "__source"
        ) {
          props[propName] = config[propName];
        }
      }
    }

    // Children can be more than one argument, and those are transferred onto
    // the newly allocated props object.
    const childrenLength = arguments.length - 2;
    if (childrenLength === 1) {
      props.children = children;
    } else if (childrenLength > 1) {
      const childArray = Array(childrenLength);
      for (let i = 0; i < childrenLength; i++) {
        childArray[i] = arguments[i + 2];
      }
      props.children = childArray;
    }

    // Resolve default props
    if (type && type.defaultProps) {
      const defaultProps = type.defaultProps;
      for (propName in defaultProps) {
        if (props[propName] === undefined) {
          props[propName] = defaultProps[propName];
        }
      }
    }
    return ReactElement(type, key, undefined, undefined, getOwner(), props);
  }
  function cloneAndReplaceKey(oldElement, newKey) {
    const clonedElement = ReactElement(
      oldElement.type,
      newKey,
      undefined,
      undefined,
      undefined,
      oldElement.props
    );
    return clonedElement;
  }

  /**
   * Clone and return a new ReactElement using element as the starting point.
   * See https://reactjs.org/docs/react-api.html#cloneelement
   */
  function cloneElement(element, config, children) {
    if (element === null || element === undefined) {
      throw new Error(
        `The argument must be a React element, but you passed ${element}.`
      );
    }
    let propName;

    // Original props are copied
    const props = assign({}, element.props);

    // Reserved names are extracted
    let key = element.key;

    // Owner will be preserved, unless ref is overridden
    let owner = undefined;
    if (config != null) {
      if (hasValidRef(config)) {
        owner = undefined;
      }
      if (hasValidKey(config)) {
        key = "" + config.key;
      }
      for (propName in config) {
        if (
          hasOwnProperty.call(config, propName) &&
          // Skip over reserved prop names
          propName !== "key" &&
          // ...and maybe these, too, though we currently rely on them for
          // warnings and debug information in dev. Need to decide if we're OK
          // with dropping them. In the jsx() runtime it's not an issue because
          // the data gets passed as separate arguments instead of props, but
          // it would be nice to stop relying on them entirely so we can drop
          // them from the internal Fiber field.
          propName !== "__self" &&
          propName !== "__source" &&
          // Undefined `ref` is ignored by cloneElement. We treat it the same as
          // if the property were missing. This is mostly for
          // backwards compatibility.
          !(propName === "ref" && config.ref === undefined)
        ) {
          {
            props[propName] = config[propName];
          }
        }
      }
    }

    // Children can be more than one argument, and those are transferred onto
    // the newly allocated props object.
    const childrenLength = arguments.length - 2;
    if (childrenLength === 1) {
      props.children = children;
    } else if (childrenLength > 1) {
      const childArray = Array(childrenLength);
      for (let i = 0; i < childrenLength; i++) {
        childArray[i] = arguments[i + 2];
      }
      props.children = childArray;
    }
    const clonedElement = ReactElement(
      element.type,
      key,
      undefined,
      undefined,
      owner,
      props
    );
    return clonedElement;
  }

  /**
   * Verifies the object is a ReactElement.
   * See https://reactjs.org/docs/react-api.html#isvalidelement
   * @param {?object} object
   * @return {boolean} True if `object` is a ReactElement.
   * @final
   */
  function isValidElement(object) {
    return (
      typeof object === "object" &&
      object !== null &&
      object.$$typeof === REACT_ELEMENT_TYPE
    );
  }

  const SEPARATOR = ".";
  const SUBSEPARATOR = ":";

  /**
   * Escape and wrap key so it is safe to use as a reactid
   *
   * @param {string} key to be escaped.
   * @return {string} the escaped key.
   */
  function escape(key) {
    const escapeRegex = /[=:]/g;
    const escaperLookup = {
      "=": "=0",
      ":": "=2"
    };
    const escapedString = key.replace(escapeRegex, function (match) {
      // $FlowFixMe[invalid-computed-prop]
      return escaperLookup[match];
    });
    return "$" + escapedString;
  }
  const userProvidedKeyEscapeRegex = /\/+/g;
  function escapeUserProvidedKey(text) {
    return text.replace(userProvidedKeyEscapeRegex, "$&/");
  }

  /**
   * Generate a key string that identifies a element within a set.
   *
   * @param {*} element A element that could contain a manual key.
   * @param {number} index Index that is used if a manual key is not provided.
   * @return {string}
   */
  function getElementKey(element, index) {
    // Do some typechecking here since we call this blindly. We want to ensure
    // that we don't block potential future ES APIs.
    if (
      typeof element === "object" &&
      element !== null &&
      element.key != null
    ) {
      return escape("" + element.key);
    }
    // Implicit key determined by the index in the set
    return index.toString(36);
  }
  function resolveThenable(thenable) {
    switch (thenable.status) {
      case "fulfilled": {
        const fulfilledValue = thenable.value;
        return fulfilledValue;
      }
      case "rejected": {
        const rejectedError = thenable.reason;
        throw rejectedError;
      }
      default: {
        if (typeof thenable.status === "string") {
          // Only instrument the thenable if the status if not defined. If
          // it's defined, but an unknown value, assume it's been instrumented by
          // some custom userspace implementation. We treat it as "pending".
          // Attach a dummy listener, to ensure that any lazy initialization can
          // happen. Flight lazily parses JSON when the value is actually awaited.
          thenable.then(noop, noop);
        } else {
          // This is an uncached thenable that we haven't seen before.

          // TODO: Detect infinite ping loops caused by uncached promises.

          const pendingThenable = thenable;
          pendingThenable.status = "pending";
          pendingThenable.then(
            (fulfilledValue) => {
              if (thenable.status === "pending") {
                const fulfilledThenable = thenable;
                fulfilledThenable.status = "fulfilled";
                fulfilledThenable.value = fulfilledValue;
              }
            },
            (error) => {
              if (thenable.status === "pending") {
                const rejectedThenable = thenable;
                rejectedThenable.status = "rejected";
                rejectedThenable.reason = error;
              }
            }
          );
        }

        // Check one more time in case the thenable resolved synchronously.
        switch (thenable.status) {
          case "fulfilled": {
            const fulfilledThenable = thenable;
            return fulfilledThenable.value;
          }
          case "rejected": {
            const rejectedThenable = thenable;
            const rejectedError = rejectedThenable.reason;
            throw rejectedError;
          }
        }
      }
    }
    throw thenable;
  }
  function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
    const type = typeof children;
    if (type === "undefined" || type === "boolean") {
      // All of the above are perceived as null.
      children = null;
    }
    let invokeCallback = false;
    if (children === null) {
      invokeCallback = true;
    } else {
      switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = true;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = true;
              break;
            case REACT_LAZY_TYPE:
              const payload = children._payload;
              const init = children._init;
              return mapIntoArray(
                init(payload),
                array,
                escapedPrefix,
                nameSoFar,
                callback
              );
          }
      }
    }
    if (invokeCallback) {
      const child = children;
      let mappedChild = callback(child);
      // If it's the only child, treat the name as if it was wrapped in an array
      // so that it's consistent if the number of children grows:
      const childKey =
        nameSoFar === "" ? SEPARATOR + getElementKey(child, 0) : nameSoFar;
      if (isArray(mappedChild)) {
        let escapedChildKey = "";
        if (childKey != null) {
          escapedChildKey = escapeUserProvidedKey(childKey) + "/";
        }
        mapIntoArray(mappedChild, array, escapedChildKey, "", (c) => c);
      } else if (mappedChild != null) {
        if (isValidElement(mappedChild)) {
          const newChild = cloneAndReplaceKey(
            mappedChild,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            escapedPrefix +
              // $FlowFixMe[incompatible-type] Flow incorrectly thinks React.Portal doesn't have a key
              (mappedChild.key != null &&
              (!child || child.key !== mappedChild.key)
                ? escapeUserProvidedKey(
                    // $FlowFixMe[unsafe-addition]
                    "" + mappedChild.key // eslint-disable-line react-internal/safe-string-coercion
                  ) + "/"
                : "") +
              childKey
          );
          mappedChild = newChild;
        }
        array.push(mappedChild);
      }
      return 1;
    }
    let child;
    let nextName;
    let subtreeCount = 0; // Count of children found in the current subtree.
    const nextNamePrefix =
      nameSoFar === "" ? SEPARATOR : nameSoFar + SUBSEPARATOR;
    if (isArray(children)) {
      for (let i = 0; i < children.length; i++) {
        child = children[i];
        nextName = nextNamePrefix + getElementKey(child, i);
        subtreeCount += mapIntoArray(
          child,
          array,
          escapedPrefix,
          nextName,
          callback
        );
      }
    } else {
      const iteratorFn = getIteratorFn(children);
      if (typeof iteratorFn === "function") {
        const iterableChildren = children;
        const iterator = iteratorFn.call(iterableChildren);
        let step;
        let ii = 0;
        // $FlowFixMe[incompatible-use] `iteratorFn` might return null according to typing.
        while (!(step = iterator.next()).done) {
          child = step.value;
          nextName = nextNamePrefix + getElementKey(child, ii++);
          subtreeCount += mapIntoArray(
            child,
            array,
            escapedPrefix,
            nextName,
            callback
          );
        }
      } else if (type === "object") {
        if (typeof children.then === "function") {
          return mapIntoArray(
            resolveThenable(children),
            array,
            escapedPrefix,
            nameSoFar,
            callback
          );
        }

        // eslint-disable-next-line react-internal/safe-string-coercion
        const childrenString = String(children);
        throw new Error(
          `Objects are not valid as a React child (found: ${childrenString === "[object Object]" ? "object with keys {" + Object.keys(children).join(", ") + "}" : childrenString}). ` +
            "If you meant to render a collection of children, use an array " +
            "instead."
        );
      }
    }
    return subtreeCount;
  }

  /**
   * Maps children that are typically specified as `props.children`.
   *
   * See https://reactjs.org/docs/react-api.html#reactchildrenmap
   *
   * The provided mapFunction(child, index) will be called for each
   * leaf child.
   *
   * @param {?*} children Children tree container.
   * @param {function(*, int)} func The map function.
   * @param {*} context Context for mapFunction.
   * @return {object} Object containing the ordered map of results.
   */
  function mapChildren(children, func, context) {
    if (children == null) {
      // $FlowFixMe limitation refining abstract types in Flow
      return children;
    }
    const result = [];
    let count = 0;
    mapIntoArray(children, result, "", "", function (child) {
      return func.call(context, child, count++);
    });
    return result;
  }

  /**
   * Count the number of children that are typically specified as
   * `props.children`.
   *
   * See https://reactjs.org/docs/react-api.html#reactchildrencount
   *
   * @param {?*} children Children tree container.
   * @return {number} The number of children.
   */
  function countChildren(children) {
    let n = 0;
    mapChildren(children, () => {
      n++;
      // Don't return anything
    });
    return n;
  }

  /**
   * Iterates through children that are typically specified as `props.children`.
   *
   * See https://reactjs.org/docs/react-api.html#reactchildrenforeach
   *
   * The provided forEachFunc(child, index) will be called for each
   * leaf child.
   *
   * @param {?*} children Children tree container.
   * @param {function(*, int)} forEachFunc
   * @param {*} forEachContext Context for forEachContext.
   */
  function forEachChildren(children, forEachFunc, forEachContext) {
    mapChildren(
      children,
      // $FlowFixMe[missing-this-annot]
      function () {
        forEachFunc.apply(this, arguments);
        // Don't return anything.
      },
      forEachContext
    );
  }

  /**
   * Flatten a children object (typically specified as `props.children`) and
   * return an array with appropriately re-keyed children.
   *
   * See https://reactjs.org/docs/react-api.html#reactchildrentoarray
   */
  function toArray(children) {
    return mapChildren(children, (child) => child) || [];
  }

  /**
   * Returns the first child in a collection of children and verifies that there
   * is only one child in the collection.
   *
   * See https://reactjs.org/docs/react-api.html#reactchildrenonly
   *
   * The current implementation of this function assumes that a single child gets
   * passed without a wrapper, but the purpose of this helper function is to
   * abstract away the particular structure of children.
   *
   * @param {?object} children Child collection structure.
   * @return {ReactElement} The first and only `ReactElement` contained in the
   * structure.
   */
  function onlyChild(children) {
    if (!isValidElement(children)) {
      throw new Error(
        "React.Children.only expected to receive a single React element child."
      );
    }
    return children;
  }

  function createContext(defaultValue) {
    // TODO: Second argument used to be an optional `calculateChangedBits`
    // function. Warn to reserve for future use?

    const context = {
      $$typeof: REACT_CONTEXT_TYPE,
      // As a workaround to support multiple concurrent renderers, we categorize
      // some renderers as primary and others as secondary. We only expect
      // there to be two concurrent renderers at most: React Native (primary) and
      // Fabric (secondary); React DOM (primary) and React ART (secondary).
      // Secondary renderers store their context values on separate fields.
      _currentValue: defaultValue,
      _currentValue2: defaultValue,
      // Used to track how many concurrent renderers this context currently
      // supports within in a single renderer. Such as parallel server rendering.
      _threadCount: 0,
      // These are circular
      Provider: null,
      Consumer: null
    };
    {
      context.Provider = context;
      context.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: context
      };
    }
    return context;
  }

  const Uninitialized = -1;
  const Pending = 0;
  const Resolved = 1;
  const Rejected = 2;
  function lazyInitializer(payload) {
    if (payload._status === Uninitialized) {
      const ctor = payload._result;
      const thenable = ctor();
      // Transition to the next state.
      // This might throw either because it's missing or throws. If so, we treat it
      // as still uninitialized and try again next time. Which is the same as what
      // happens if the ctor or any wrappers processing the ctor throws. This might
      // end up fixing it if the resolution was a concurrency bug.
      thenable.then(
        (moduleObject) => {
          if (
            payload._status === Pending ||
            payload._status === Uninitialized
          ) {
            // Transition to the next state.
            const resolved = payload;
            resolved._status = Resolved;
            resolved._result = moduleObject;
          }
        },
        (error) => {
          if (
            payload._status === Pending ||
            payload._status === Uninitialized
          ) {
            // Transition to the next state.
            const rejected = payload;
            rejected._status = Rejected;
            rejected._result = error;
          }
        }
      );
      if (payload._status === Uninitialized) {
        // In case, we're still uninitialized, then we're waiting for the thenable
        // to resolve. Set it as pending in the meantime.
        const pending = payload;
        pending._status = Pending;
        pending._result = thenable;
      }
    }
    if (payload._status === Resolved) {
      const moduleObject = payload._result;
      return moduleObject.default;
    } else {
      throw payload._result;
    }
  }
  function lazy(ctor) {
    const payload = {
      // We use these fields to store the result.
      _status: Uninitialized,
      _result: ctor
    };
    const lazyType = {
      $$typeof: REACT_LAZY_TYPE,
      _payload: payload,
      _init: lazyInitializer
    };
    return lazyType;
  }

  function forwardRef(render) {
    const elementType = {
      $$typeof: REACT_FORWARD_REF_TYPE,
      render
    };
    return elementType;
  }

  function memo(type, compare) {
    const elementType = {
      $$typeof: REACT_MEMO_TYPE,
      type,
      compare: compare === undefined ? null : compare
    };
    return elementType;
  }

  function noopCache(fn) {
    // On the client (i.e. not a Server Components environment) `cache` has
    // no caching behavior. We just return the function as-is.
    //
    // We intend to implement client caching in a future major release. In the
    // meantime, it's only exposed as an API so that Shared Components can use
    // per-request caching on the server without breaking on the client. But it
    // does mean they need to be aware of the behavioral difference.
    //
    // The rest of the behavior is the same as the server implementation — it
    // returns a new reference, extra properties like `displayName` are not
    // preserved, the length of the new function is 0, etc. That way apps can't
    // accidentally depend on those details.
    return function () {
      // $FlowFixMe[incompatible-call]: We don't want to use rest arguments since we transpile the code.
      return fn.apply(null, arguments);
    };
  }
  const cache = noopCache;

  function postpone(reason) {
    // eslint-disable-next-line react-internal/prod-error-codes
    const postponeInstance = new Error(reason);
    postponeInstance.$$typeof = REACT_POSTPONE_TYPE;
    throw postponeInstance;
  }

  function resolveDispatcher() {
    const dispatcher = ReactSharedInternals.H;
    // Will result in a null access error if accessed outside render phase. We
    // intentionally don't throw our own error because this is in a hot path.
    // Also helps ensure this is inlined.
    return dispatcher;
  }
  function getCacheForType(resourceType) {
    const dispatcher = ReactSharedInternals.A;
    if (!dispatcher) {
      // If there is no dispatcher, then we treat this as not being cached.
      return resourceType();
    }
    return dispatcher.getCacheForType(resourceType);
  }
  function useContext(Context) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useContext(Context);
  }
  function useState(initialState) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useState(initialState);
  }
  function useReducer(reducer, initialArg, init) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useReducer(reducer, initialArg, init);
  }
  function useRef(initialValue) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useRef(initialValue);
  }
  function useEffect(create, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useEffect(create, deps);
  }
  function useInsertionEffect(create, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useInsertionEffect(create, deps);
  }
  function useLayoutEffect(create, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useLayoutEffect(create, deps);
  }
  function useCallback(callback, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useCallback(callback, deps);
  }
  function useMemo(create, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useMemo(create, deps);
  }
  function useImperativeHandle(ref, create, deps) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useImperativeHandle(ref, create, deps);
  }
  function useDebugValue(value, formatterFn) {}
  function useTransition() {
    const dispatcher = resolveDispatcher();
    return dispatcher.useTransition();
  }
  function useDeferredValue(value, initialValue) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useDeferredValue(value, initialValue);
  }
  function useId() {
    const dispatcher = resolveDispatcher();
    return dispatcher.useId();
  }
  function useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useSyncExternalStore(
      subscribe,
      getSnapshot,
      getServerSnapshot
    );
  }
  function useCacheRefresh() {
    const dispatcher = resolveDispatcher();
    // $FlowFixMe[not-a-function] This is unstable, thus optional
    return dispatcher.useCacheRefresh();
  }
  function use(usable) {
    const dispatcher = resolveDispatcher();
    return dispatcher.use(usable);
  }
  function useMemoCache(size) {
    const dispatcher = resolveDispatcher();
    // $FlowFixMe[not-a-function] This is unstable, thus optional
    return dispatcher.useMemoCache(size);
  }
  function useEffectEvent(callback) {
    const dispatcher = resolveDispatcher();
    // $FlowFixMe[not-a-function] This is unstable, thus optional
    return dispatcher.useEffectEvent(callback);
  }
  function useOptimistic(passthrough, reducer) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useOptimistic(passthrough, reducer);
  }
  function useActionState(action, initialState, permalink) {
    const dispatcher = resolveDispatcher();
    return dispatcher.useActionState(action, initialState, permalink);
  }

  const reportGlobalError =
    typeof reportError === "function"
      ? // In modern browsers, reportError will dispatch an error event,
        // emulating an uncaught JavaScript error.
        reportError
      : (error) => {
          if (
            typeof window === "object" &&
            typeof window.ErrorEvent === "function"
          ) {
            // Browser Polyfill
            const message =
              typeof error === "object" &&
              error !== null &&
              typeof error.message === "string"
                ? // eslint-disable-next-line react-internal/safe-string-coercion
                  String(error.message)
                : // eslint-disable-next-line react-internal/safe-string-coercion
                  String(error);
            const event = new window.ErrorEvent("error", {
              bubbles: true,
              cancelable: true,
              message: message,
              error: error
            });
            const shouldLog = window.dispatchEvent(event);
            if (!shouldLog) {
              return;
            }
          } else if (
            typeof process === "object" &&
            // $FlowFixMe[method-unbinding]
            typeof process.emit === "function"
          ) {
            // Node Polyfill
            process.emit("uncaughtException", error);
            return;
          }
          console["error"](error);
        };

  function releaseAsyncTransition() {}
  function startTransition(scope, options) {
    const prevTransition = ReactSharedInternals.T;
    const currentTransition = {};
    {
      currentTransition.types =
        prevTransition !== null
          ? // If we're a nested transition, we should use the same set as the parent
            // since we're conceptually always joined into the same entangled transition.
            // In practice, this only matters if we add transition types in the inner
            // without setting state. In that case, the inner transition can finish
            // without waiting for the outer.
            prevTransition.types
          : null;
    }
    {
      currentTransition.gesture = null;
    }
    ReactSharedInternals.T = currentTransition;
    try {
      const returnValue = scope();
      const onStartTransitionFinish = ReactSharedInternals.S;
      if (onStartTransitionFinish !== null) {
        onStartTransitionFinish(currentTransition, returnValue);
      }
      if (
        typeof returnValue === "object" &&
        returnValue !== null &&
        typeof returnValue.then === "function"
      ) {
        if (false);
        returnValue.then(noop, reportGlobalError);
      }
    } catch (error) {
      reportGlobalError(error);
    } finally {
      if (prevTransition !== null && currentTransition.types !== null) {
        prevTransition.types = currentTransition.types;
      }
      ReactSharedInternals.T = prevTransition;
    }
  }
  function startGestureTransition(provider, scope, options) {
    if (provider == null) {
      // We enforce this at runtime even though the type also enforces it since we
      // use null as a signal internally so it would lead it to be treated as a
      // regular transition otherwise.
      throw new Error(
        "A Timeline is required as the first argument to startGestureTransition."
      );
    }
    const prevTransition = ReactSharedInternals.T;
    const currentTransition = {};
    {
      currentTransition.types = null;
    }
    {
      currentTransition.gesture = provider;
    }
    ReactSharedInternals.T = currentTransition;
    try {
      const returnValue = scope();
      if (false);
      const onStartGestureTransitionFinish = ReactSharedInternals.G;
      if (onStartGestureTransitionFinish !== null) {
        return onStartGestureTransitionFinish(
          currentTransition,
          provider,
          options
        );
      }
    } catch (error) {
      reportGlobalError(error);
    } finally {
      ReactSharedInternals.T = prevTransition;
    }
    return noop;
  }

  function addTransitionType(type) {
    {
      const transition = ReactSharedInternals.T;
      if (transition !== null) {
        const transitionTypes = transition.types;
        if (transitionTypes === null) {
          transition.types = [type];
        } else if (transitionTypes.indexOf(type) === -1) {
          transitionTypes.push(type);
        }
      } else {
        startTransition(addTransitionType.bind(null, type));
      }
    }
  }

  function act(callback) {
    {
      throw new Error(
        "act(...) is not supported in production builds of React."
      );
    }
  }

  function captureOwnerStack() {
    return null;
  }

  var ReactCompilerRuntime = /*#__PURE__*/ Object.freeze({
    __proto__: null,
    c: useMemoCache
  });

  const Children = {
    map: mapChildren,
    forEach: forEachChildren,
    count: countChildren,
    toArray,
    only: onlyChild
  };

  function experimental_useOptimistic(passthrough, reducer) {
    return useOptimistic(passthrough, reducer);
  }

  exports.Children = Children;
  exports.Component = Component;
  exports.Fragment = REACT_FRAGMENT_TYPE;
  exports.Profiler = REACT_PROFILER_TYPE;
  exports.PureComponent = PureComponent;
  exports.StrictMode = REACT_STRICT_MODE_TYPE;
  exports.Suspense = REACT_SUSPENSE_TYPE;
  exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE =
    ReactSharedInternals;
  exports.__COMPILER_RUNTIME = ReactCompilerRuntime;
  exports.act = act;
  exports.cache = cache;
  exports.captureOwnerStack = captureOwnerStack;
  exports.cloneElement = cloneElement;
  exports.createContext = createContext;
  exports.createElement = createElement;
  exports.createRef = createRef;
  exports.experimental_useEffectEvent = useEffectEvent;
  exports.experimental_useOptimistic = experimental_useOptimistic;
  exports.forwardRef = forwardRef;
  exports.isValidElement = isValidElement;
  exports.lazy = lazy;
  exports.memo = memo;
  exports.startTransition = startTransition;
  exports.unstable_Activity = REACT_ACTIVITY_TYPE;
  exports.unstable_SuspenseList = REACT_SUSPENSE_LIST_TYPE;
  exports.unstable_ViewTransition = REACT_VIEW_TRANSITION_TYPE;
  exports.unstable_addTransitionType = addTransitionType;
  exports.unstable_getCacheForType = getCacheForType;
  exports.unstable_postpone = postpone;
  exports.unstable_startGestureTransition = startGestureTransition;
  exports.unstable_useCacheRefresh = useCacheRefresh;
  exports.use = use;
  exports.useActionState = useActionState;
  exports.useCallback = useCallback;
  exports.useContext = useContext;
  exports.useDebugValue = useDebugValue;
  exports.useDeferredValue = useDeferredValue;
  exports.useEffect = useEffect;
  exports.useId = useId;
  exports.useImperativeHandle = useImperativeHandle;
  exports.useInsertionEffect = useInsertionEffect;
  exports.useLayoutEffect = useLayoutEffect;
  exports.useMemo = useMemo;
  exports.useOptimistic = useOptimistic;
  exports.useReducer = useReducer;
  exports.useRef = useRef;
  exports.useState = useState;
  exports.useSyncExternalStore = useSyncExternalStore;
  exports.useTransition = useTransition;
  exports.version = ReactVersion;
});
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop ===
    "function"
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
}
