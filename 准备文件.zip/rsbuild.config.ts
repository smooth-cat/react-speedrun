import { defineConfig } from '@rsbuild/core';
import { pluginReact } from '@rsbuild/plugin-react';

export default defineConfig({
  plugins: [pluginReact()],
  html: {
    template: './public/index.html'
  },
  dev: {
    watchFiles: [{
      paths: ['**/public/*.js', '**/src/**'],
    }]
  },
  output: {
    externals: {
      react: 'React',
      'react-dom/client': 'ReactDOM',
      'react/jsx-dev-runtime': 'JSXDEVRuntime',
      scheduler: 'Scheduler'
    }
  }
});
